if __name__ == '__main__':
    fp = open('mydata.txt',"r")
    print(fp.read())
    fp.close()
